/**
 *
 * @author ALUMNOS
 */
interface InterfaceColorARGB {
    public ColorARGB(int alpha, int red, int green, int blue);
    
}
